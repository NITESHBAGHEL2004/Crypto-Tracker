export default [
  {
    name: 'Bitcoin', symbol: 'BTC', price: '93759.48', change1h: '0.43', change24h: '0.93',
    change7d: '11.11', marketCap: '1861618902186', volume: '4374950947',
    circulating: '19.85M BTC', maxSupply: '21M BTC', logo: 'https://cryptologos.cc/logos/bitcoin-btc-logo.png',
    chart: 'https://via.placeholder.com/50x20?text=BTC+Chart'
  },
  {
    name: 'Ethereum', symbol: 'ETH', price: '1802.46', change1h: '0.60', change24h: '3.21',
    change7d: '13.68', marketCap: '217581279327', volume: '2347469307',
    circulating: '120.71M ETH', maxSupply: '∞', logo: 'https://cryptologos.cc/logos/ethereum-eth-logo.png',
    chart: 'https://via.placeholder.com/50x20?text=ETH+Chart'
  },
  // Additional assets ...
];

import { createSlice } from '@reduxjs/toolkit';
import initialData from './initialData';

const cryptoSlice = createSlice({
  name: 'crypto',
  initialState: { assets: initialData },
  reducers: {
    updateCryptoPrices: (state) => {
      state.assets = state.assets.map(asset => ({
        ...asset,
        price: (parseFloat(asset.price) * (1 + (Math.random() - 0.5) * 0.02)).toFixed(2),
        change1h: (Math.random() * 2 - 1).toFixed(2),
        change24h: (Math.random() * 2 - 1).toFixed(2),
        change7d: (Math.random() * 2 - 1).toFixed(2),
        volume: (parseFloat(asset.volume) * (1 + (Math.random() - 0.5) * 0.1)).toFixed(2)
      }));
    }
  }
});

export const { updateCryptoPrices } = cryptoSlice.actions;
export default cryptoSlice.reducer;

import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { updateCryptoPrices } from '../features/cryptoSlice';

function CryptoTable() {
  const dispatch = useDispatch();
  const data = useSelector(state => state.crypto.assets);

  useEffect(() => {
    const interval = setInterval(() => {
      dispatch(updateCryptoPrices());
    }, 2000);
    return () => clearInterval(interval);
  }, [dispatch]);

  return (
    <table>
      <thead>
        <tr>
          <th>#</th><th>Logo</th><th>Name</th><th>Symbol</th><th>Price</th>
          <th>1h %</th><th>24h %</th><th>7d %</th><th>Market Cap</th>
          <th>24h Volume</th><th>Circulating Supply</th><th>Max Supply</th><th>7D Chart</th>
        </tr>
      </thead>
      <tbody>
        {data.map((asset, index) => (
          <tr key={index}>
            <td>{index + 1}</td>
            <td><img src={asset.logo} alt={asset.symbol} width="20" /></td>
            <td>{asset.name}</td>
            <td>{asset.symbol}</td>
            <td>${asset.price}</td>
            <td style={{ color: asset.change1h >= 0 ? 'green' : 'red' }}>{asset.change1h}%</td>
            <td style={{ color: asset.change24h >= 0 ? 'green' : 'red' }}>{asset.change24h}%</td>
            <td style={{ color: asset.change7d >= 0 ? 'green' : 'red' }}>{asset.change7d}%</td>
            <td>${asset.marketCap}</td>
            <td>${asset.volume}</td>
            <td>{asset.circulating}</td>
            <td>{asset.maxSupply}</td>
            <td><img src={asset.chart} alt="chart" width="50" /></td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

export default CryptoTable;

# Real-Time Crypto Price Tracker

## Overview
This is a React + Redux Toolkit app that simulates real-time cryptocurrency price tracking. The table updates every 1–2 seconds using mocked WebSocket updates.

## Features
- Responsive UI table for top 5 cryptocurrencies.
- Real-time price updates using setInterval.
- Redux Toolkit for state management.
- Color-coded % change.
- Static 7D charts.

## How to Run
1. Clone the repository.
2. Run `npm install` to install dependencies.
3. Run `npm start` to start the application.

## Tech Stack
- React
- Redux Toolkit
- JavaScript
